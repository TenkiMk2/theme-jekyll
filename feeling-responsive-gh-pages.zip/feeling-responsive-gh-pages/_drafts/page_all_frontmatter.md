---
layout: page
subheadline: 
title: 
teaser: 
meta_title:             # SEO: Overwrites title in <head> if needed
meta_description:
permalink:
categories:
    - 
tags:
    - 
header: no
header:
    image_fullwidth: 
    image:
    pattern:
    color:
    background-color: "#fabb00"
    title: 
    caption: 
    caption_url: 
image:
    title:
    homepage:
    thumb:
    caption:
    caption_url:
style:                      # Adding additional CSS-styles to <head>
iframe: ""
video:
    embedURL: ""
    contentURL: ""
    thumbnailUrl: ""
show_meta: false
sidebar: left
comments: true
breadcrumb: true
---

